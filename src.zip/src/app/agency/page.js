"use client";

import { useEffect, useState } from "react";
import BottomNav from "../components/BottomNav";
import { IconWallet, IconQr } from "../icons";

const STATS = [
  { key: "referrals", label: "Referred users" },
  { key: "depositedReferrals", label: "Referrals who deposited", tone: "green" },
  { key: "depositAmount", label: "Total deposit amount", tone: "orange", money: true },
  { key: "depositCount", label: "Total deposit count" },
];

export default function AgencyPage() {
  const [range, setRange] = useState("all");
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [popup, setPopup] = useState(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    fetch(`/api/agency/stats?range=${range}`)
      .then((res) => (res.ok ? res.json() : Promise.reject()))
      .then((data) => {
        if (!cancelled) setStats(data);
      })
      .catch(() => {
        if (!cancelled) setStats(null);
      })
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [range]);

  const values = {
    referrals: stats?.referrals ?? 0,
    depositedReferrals: stats?.depositedReferrals ?? 0,
    depositAmount: stats?.depositAmount ?? 0,
    depositCount: stats?.depositCount ?? 0,
  };

  return (
    <div className="kk-page">
      <header className="kk-header">
        <span className="kk-header-side" />
        <span className="kk-header-title">Agency</span>
        <button className="kk-header-icon-btn" onClick={() => setPopup("Agency records")}>
          <IconWallet />
        </button>
      </header>

      <main>
        <section className="kk-agency-banner">
          <div className="big">{values.referrals}</div>
          <div className="pill">Your total referrals</div>
          <div className="note">Share your invite code to grow your referral network</div>
        </section>

        <div className="kk-agency-tabs">
          <button className={`kk-agency-tab ${range === "month" ? "active" : ""}`} onClick={() => setRange("month")}>
            This month
          </button>
          <button className={`kk-agency-tab ${range === "all" ? "active" : ""}`} onClick={() => setRange("all")}>
            All time
          </button>
        </div>

        <section className="kk-agency-stats" style={{ gridTemplateColumns: "1fr 1fr" }}>
          <div className="kk-agency-col">
            {STATS.slice(0, 2).map((s) => (
              <div className={`kk-agency-stat ${s.tone || ""}`} key={s.key}>
                <b>{loading ? "…" : s.money ? `Rs${Number(values[s.key]).toLocaleString()}` : values[s.key]}</b>
                <span>{s.label}</span>
              </div>
            ))}
          </div>
          <div className="kk-agency-col">
            {STATS.slice(2, 4).map((s) => (
              <div className={`kk-agency-stat ${s.tone || ""}`} key={s.key}>
                <b>{loading ? "…" : s.money ? `Rs${Number(values[s.key]).toLocaleString()}` : values[s.key]}</b>
                <span>{s.label}</span>
              </div>
            ))}
          </div>
        </section>

        <button className="kk-qr-btn" onClick={() => setPopup("Download QR Code")}>
          <IconQr />
          Download QR Code
        </button>

        <footer className="kk-footer">Invite friends and see how many of them deposit — real referral data, no real money.</footer>
      </main>

      <BottomNav />

      <div className={`popup ${popup ? "active" : ""}`} onClick={() => setPopup(null)}>
        <div className="kk-popup-box" onClick={(e) => e.stopPropagation()}>
          <div className="kk-popup-icon">🤝</div>
          <div className="kk-popup-title">Demo Mode</div>
          <p className="kk-popup-text">&quot;{popup}&quot; is a placeholder in this UI showcase — no real agency data is connected.</p>
          <button className="kk-popup-btn" onClick={() => setPopup(null)}>
            Got it
          </button>
        </div>
      </div>
    </div>
  );
}
